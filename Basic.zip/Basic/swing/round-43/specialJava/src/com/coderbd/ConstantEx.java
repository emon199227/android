package com.coderbd;
public class ConstantEx {
   private static final float PI=3.14f;
   private static final int NUM_OF_STUDENTS=14;
    public static void main(String[] args) {
   //    NUM_OF_STUDENTS=13;
    }
}
