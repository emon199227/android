package com.coderbd;

public class SwitchCase {

    public static void main(String[] args) {
        int x = 10;
        switch (x) {
            case 0:
                System.out.println("A");
                break;
            case 1:
                System.out.println("B");
            case 2:
                System.out.println("C");
                break;
            default:
                System.out.println("F");
            case 3:
                System.out.println("D");

        }
    }

}
