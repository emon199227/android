package com.coderbd.createtable;

/**
 *
 * @author User
 */
public class Test {

    public static void main(String[] args) {
       // CreateStudentTable.createStudentTable();
    }
}
