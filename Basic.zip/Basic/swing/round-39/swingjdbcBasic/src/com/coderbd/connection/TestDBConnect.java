package com.coderbd.connection;

public class TestDBConnect {

    public static void main(String[] args) {
        DblConnection.getDbConnection();
    }
}
